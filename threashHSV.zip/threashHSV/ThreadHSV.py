import cv2
import numpy as np

kernel = np.array([[1,1,1,1,1],[1,1,1,1,1],[1,1,1,1,1],
                 [1,1,1,1,1],[1,1,1,1,1]],dtype = np.uint8)/25 #高斯自定义5*5的卷积核


frame = cv2.imread("105.jpg")
frame = cv2.GaussianBlur(frame,(7,7),0)

hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)

low_hsv = np.array([30, 30, 50], dtype=np.uint8)

upper_hsv = np.array([150, 150, 255], dtype=np.uint8)

mask = cv2.inRange(hsv, low_hsv, upper_hsv)

# erosion = cv2.erode(mask,kernel,iterations = 1) #膨胀

# dilation = cv2.dilate(mask,kernel,iterations = 1) #腐蚀

opening = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel) #开运算，先腐蚀再膨胀。
closing = cv2.morphologyEx(opening, cv2.MORPH_CLOSE, kernel) #闭运算，先膨胀再腐蚀。

image, contours, hierarchy = cv2.findContours(closing,cv2.RETR_TREE,cv2.CHAIN_APPROX_SIMPLE)

for i,j in enumerate(contours):
    (x,y),radius = cv2.minEnclosingCircle(j)
    center = (int(x),int(y))
    radius = int(radius)
    print(center)
    print(radius)
    frame = cv2.circle(frame,center,radius,(255,255,255),2)

cv2.imshow("100001",frame)
cv2.waitKey(0)
